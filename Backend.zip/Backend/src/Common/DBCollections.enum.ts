export enum DBCollections {
  USERS = "users",
  TEXT_SURVEYS = "text-surveys",
  SCALE_SURVEYS = "scale-surveys",
  TELEMETRY = "telemetry",
}