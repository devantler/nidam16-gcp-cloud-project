export = {
  secret: "my-very-secret-secret"
}